package eighteen;

public enum Pieces {
	WHITE, BLACK, EMPTY
}
